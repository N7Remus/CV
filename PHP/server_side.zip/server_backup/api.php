<?php

$img = "/srv/cv_core/uploads/";
if (!empty($_POST["params"])) {
    /*echo '<li>';
    var_dump($_POST);
    echo '</li>';*/
    $tmp=array();
    foreach ($_POST["params"] as $key => $value) {
        if ($key!=0){
            $tmp[]=$value;
        }
    }
    $img.=$_POST["params"][0];
    $shell_exec ="export PYTHONIOENCODING=UTF-8;python3 /srv/cv_core/virtualenvironment/scan.py -i " . "'$img' -o '$img'";
// original kép
    if (in_array("median_o", $tmp))
        $shell_exec .= " -m_o 5";
    if (in_array("gauss_o", $tmp))
        $shell_exec .= " -g_o 5";
    if (in_array("bilinear_o", $tmp))
        $shell_exec .= " -b_o 1";
    if (in_array("invert_o", $tmp))
        $shell_exec .= " -n_o 1";
    if (in_array("clahe_o", $tmp))
        $shell_exec .= " -c_o 1";
    if (in_array("kvantal_o", $tmp))
        $shell_exec .= " -kv_o 32";

// Vágott kép
    if (in_array("median", $tmp))
        $shell_exec .= " -m 5";
    if (in_array("gauss", $tmp))
        $shell_exec .= " -g 5";
    if (in_array("bilinear", $tmp))
        $shell_exec .= " -b 1";
    if (in_array("invert", $tmp))
        $shell_exec .= " -n 1";
    if (in_array("clahe", $tmp))
        $shell_exec .= " -c 1";
    if (in_array("kvantal", $tmp))
        $shell_exec .= " -kv 16";

    $shell_exec .= " 2>&1";

file_put_contents( "/tmp/a",   shell_exec($shell_exec));

    //original image
    if (file_exists($img)) {
        $o = file_get_contents($img);
        if (!empty($o)) {
            echo "<li><div id='prev'><img id='img2' title='Eredeti kép' src='data:image/jpeg;base64, ";
            echo base64_encode($o);
            echo "' /></div></li>";
        }
    }
    //original image
    if (file_exists($img.".png")) {
        $o = file_get_contents($img.".png");
        if (!empty($o)) {
            echo "<li><div id='prev'><img id='img2' title='Eredeti kép-javítva' src='data:image/jpeg;base64, ";
            echo base64_encode($o);
            echo "' /></div></li>";
        }
    }

    //kimelt warped image
    if (file_exists($img . ".jpg")) {
        $o = file_get_contents($img . ".jpg");
        if (!empty($o)) {
            echo "<li><div id='prev'><img id='img2' title='Megtalált él kiemelve' src='data:image/jpeg;base64, ";
            echo base64_encode($o);
            echo "' /></div></li>";
        }
    }
    //vágott warped image
    if (file_exists($img . ".jpeg")) {
        $o = file_get_contents($img . ".jpeg");
        if (!empty($o)) {
            echo "<li><div id='prev'><img id='img2' title='Megtalált él megvágva' src='data:image/jpeg;base64, ";
            echo base64_encode($o);
            echo "' /></div></li>";
        }
    }

    // median image
    if (file_exists($img . "median.jpeg")) {
        $o = file_get_contents($img . "median.jpeg");
        if (!empty($o)) {
            echo "<li><div id='prev'><img id='img2' title='Median filterezett kép' src='data:image/jpeg;base64, ";
            echo base64_encode($o);
            echo "' /></div></li>";
        }
    }
    // gauss image
    if (file_exists($img . "gauss.jpeg")) {
        $o = file_get_contents($img . "gauss.jpeg");
        if (!empty($o)) {
            echo "<li><div id='prev'><img id='img2' title='Gaussian zajcsökkentés' src='data:image/jpeg;base64, ";
            echo base64_encode($o);
            echo "' /></div></li>";
        }
    }
    // bilinear image
    if (file_exists($img . "bilinear.jpeg")) {
        $o = file_get_contents($img . "bilinear.jpeg");
        if (!empty($o)) {
            echo "<li><div id='prev'><img id='img2' title='Bilinearis Filterezés' src='data:image/jpeg;base64, ";
            echo base64_encode($o);
            echo "' /></div></li>";
        }
    }
    // invert image
    if (file_exists($img . "invert.jpeg")) {
        $o = file_get_contents($img . "invert.jpeg");
        if (!empty($o)) {
            echo "<li><div id='prev'><img id='img2' title='Negatív kép' src='data:image/jpeg;base64, ";
            echo base64_encode($o);
            echo "' /></div></li>";
        }
    }
    // clahe image
    if (file_exists($img . "clahe.jpeg")) {
        $o = file_get_contents($img . "clahe.jpeg");
        if (!empty($o)) {
            echo "<li><div id='prev'><img id='img2' title='Contrast Limited Adaptive Histogram Equalization' src='data:image/jpeg;base64, ";
            echo base64_encode($o);
            echo "' /></div></li>";
        }
    }
// kvantalas
    if (file_exists($img . "kvantalas.jpeg")) {
        $o = file_get_contents($img . "kvantalas.jpeg");
        if (!empty($o)) {
            echo "<li><div id='prev'><img id='img2' title='Kvantalás' src='data:image/jpeg;base64, ";
            echo base64_encode($o);
            echo "' /></div></li>";
        }
    }
    echo '<li>';
    echo 'DONE';
    echo '</li>';
}
exit();
?>


